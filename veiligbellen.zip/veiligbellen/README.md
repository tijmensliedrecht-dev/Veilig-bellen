# VeiligBellen — Next.js Prototype

> *Extra bescherming tegen telefonische oplichting.*

Een volledig klikbaar mobile app prototype gebouwd met Next.js 14 + TypeScript.

---

## Snel starten

```bash
# 1. Installeer dependencies
npm install

# 2. Start de dev server
npm run dev

# 3. Open in browser
# → http://localhost:3000
```

---

## Projectstructuur

```
src/app/
├── page.tsx                  # Startpunt
├── layout.tsx                # HTML shell + metadata
├── globals.css               # Design tokens & globale stijlen
├── context.tsx               # Globale state (scherm, contacten, timer)
├── types.ts                  # TypeScript types
│
├── components/
│   ├── PhoneShell.tsx        # Phone-frame + screen router
│   └── UI.tsx                # Herbruikbare componenten (Btn, Card, Avatar…)
│
└── screens/
    ├── SplashScreen.tsx      # 1. Splash
    ├── WelcomeScreen.tsx     # 2. Welkom
    ├── UitlegScreen.tsx      # 3. Uitleg (3 kaarten)
    ├── ContactenScreen.tsx   # 4. Vertrouwde contacten
    ├── FamilieScreen.tsx     # 5. Familie koppelen
    ├── InstellingenScreen.tsx# 6. Instellingen
    ├── DashboardScreen.tsx   # 7. Dashboard
    ├── SimulatieScreen.tsx   # 8. Simulatie (live timer)
    ├── NotificatieScreen.tsx # 9. Notificatie
    ├── FamilieDashboardScreen.tsx # 10. Familie dashboard
    ├── BerichtScreen.tsx     # 11. Bericht sturen
    └── DetailsScreen.tsx     # 12. Gespreksdetails
```

---

## Deployen op Vercel (gratis)

```bash
# Installeer Vercel CLI
npm i -g vercel

# Deploy
vercel

# → Je krijgt direct een live URL
```

Of ga naar [vercel.com](https://vercel.com), koppel je GitHub repo en klik Deploy.

---

## Kleuren

| Token     | Kleur    | Gebruik          |
|-----------|----------|------------------|
| `--pb`    | #5B5CEB  | Primair / brand  |
| `--pb2`   | #EEF2FF  | Licht accent bg  |
| `--ok`    | #22C55E  | Succes / actief  |
| `--warn`  | #F59E0B  | Waarschuwing     |
| `--red`   | #EF4444  | Alarm / gevaar   |
| `--bg`    | #FAFAFA  | Achtergrond      |

---

## Gebouwd met

- [Next.js 14](https://nextjs.org) (App Router)
- TypeScript
- React Context voor state
- Geen externe UI-libraries — alles custom
